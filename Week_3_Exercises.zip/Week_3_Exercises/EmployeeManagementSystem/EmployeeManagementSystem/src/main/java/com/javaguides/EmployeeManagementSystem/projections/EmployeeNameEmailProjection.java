package com.javaguides.EmployeeManagementSystem.projections;
public interface EmployeeNameEmailProjection {
	String getName();
	String getEmail();

}
