package com.javaguides.EmployeeManagementSystem.repository;
import com.javaguides.EmployeeManagementSystem.entity.Employee;
import com.javaguides.EmployeeManagementSystem.projections.EmployeeNameEmailDTO;
import com.javaguides.EmployeeManagementSystem.projections.EmployeeNameEmailProjection;
import com.javaguides.EmployeeManagementSystem.projections.EmployeeNameWithDomainProjection;

import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

// import com.javaguides.EmployeeManagementSystem.entity.Employee;
import java.util.*;
@SuppressWarnings("unused")
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>, PagingAndSortingRepository<Employee, Long> {
    List<Employee> findByName(String name);
    List<Employee> findByDepartmentName(String departmentName);
    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Employee findByEmail(@Param("email") String email);
    @Query("SELECT e FROM Employee e WHERE e.department.id = :departmentId")
    List<Employee> findByDepartmentId(@Param("departmentId") Long departmentId);
    @Query(name = "Employee.findByDepartment")
    List<Employee> findByDepartment(@Param("departmentName") String departmentName);
    @Query(name = "Employee.findAllOrderByName")
    List<Employee> findAllOrderByName();
    List<EmployeeNameEmailProjection> findAllBy();
    @Query("SELECT new com.javaguides.projections.EmployeeNameEmailDTO(e.name, e.email) FROM Employee e")
    List<EmployeeNameEmailDTO> findAllEmployeeNamesandEmails();
    @Query("SELECT e FROM Employee e")
    List<EmployeeNameWithDomainProjection> findAllNameWithDomain();
    @Query("SELECT e.name AS name, e.email AS email, " +
           "CONCAT(e.name, ' (', SUBSTRING(e.email, LOCATE('@', e.email) + 1), ')') AS displayName " +
           "FROM Employee e")
    List<EmployeeNameEmailProjection> findAllProjectedBy();
	@Query("SELECT e.name as name,e.email as email FROM Employee e")
	List<EmployeeNameEmailProjection> findByEmployee();
	@Query("SELECT e.name as name,e.email as email FROM Employee e WHERE e.department.name =:departmentName")
	List<EmployeeNameWithDomainProjection>findByDepartmentName1(@Param("departmentName") String departmentName);
    Page<Employee> findall(Pageable pageable);
}
