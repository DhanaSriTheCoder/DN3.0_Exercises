package com.example.bookstoreapi.service;
import com.example.bookstoreapi.model.Book;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
public class BookService {
    private List<Book> books = new ArrayList<>();
    private long nextId = 1L;
    public Book createBook(Book book) {
        book.setId(nextId++);
        books.add(book);
        return book;
    }
    public List<Book> findAllBooks() {
        return new ArrayList<>(books);
    }
    public Book findBookById(Long id) {
        return books.stream()
                .filter(book -> book.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Book not found with ID " + id));
    }
    public Book updateBook(Long id, Book updatedBook) {
        Book book = findBookById(id);
        book.setTitle(updatedBook.getTitle());
        book.setAuthor(updatedBook.getAuthor());
        book.setPrice(updatedBook.getPrice());
        book.setIsbn(updatedBook.getIsbn());
        return book;
    }
    public void deleteBook(Long id) {
        books.removeIf(book -> book.getId().equals(id));
    }
}
