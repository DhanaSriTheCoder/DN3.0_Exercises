import java.util.Arrays;
class Order {
    private final int orderId;
    private final String customerName;
    private final double totalPrice;
    public Order(int orderId, String customerName, double totalPrice) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }
    public int getOrderId() {
        return orderId;
    }
    public String getCustomerName() {
        return customerName;
    }
    public double getTotalPrice() {
        return totalPrice;
    }
    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", customerName='" + customerName + '\'' +
                ", totalPrice=" + totalPrice +
                '}';
    }
}
public class SortOrders {
    private static void bubbleSort(Order[] orders) {
        int n = orders.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice()) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped) break;
        }
    }
    private static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }
    private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (orders[j].getTotalPrice() <= pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }
    private static void mergeSort(Order[] orders, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(orders, left, mid);
            mergeSort(orders, mid + 1, right);
            merge(orders, left, mid, right);
        }
    }
    private static void merge(Order[] orders, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        Order[] leftArray = new Order[n1];
        Order[] rightArray = new Order[n2];
        System.arraycopy(orders, left, leftArray, 0, n1);
        System.arraycopy(orders, mid + 1, rightArray, 0, n2);
        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (leftArray[i].getTotalPrice() <= rightArray[j].getTotalPrice()) {
                orders[k] = leftArray[i];
                i++;
            } else {
                orders[k] = rightArray[j];
                j++;
            }
            k++;
        }
        while (i < n1) {
            orders[k] = leftArray[i];
            i++;
            k++;
        }
        while (j < n2) {
            orders[k] = rightArray[j];
            j++;
            k++;
        }
    }
    private static void insertionSort(Order[] orders) {
        int n = orders.length;
        for (int i = 1; i < n; i++) {
            Order key = orders[i];
            int j = i - 1;
            while (j >= 0 && orders[j].getTotalPrice() > key.getTotalPrice()) {
                orders[j + 1] = orders[j];
                j = j - 1;
            }
            orders[j + 1] = key;
        }
    }
    public static void main(String[] args) {
        Order[] orders = {
            new Order(1, "Alice", 250.50),
            new Order(2, "Bob", 150.75),
            new Order(3, "Charlie", 300.40),
            new Order(4, "David", 200.00),
            new Order(5, "Eve", 175.25)
        };
        System.out.println("Original Orders:");
        printOrders(orders);
        bubbleSort(orders);
        System.out.println("\nOrders sorted by Bubble Sort:");
        printOrders(orders);
        orders = new Order[]{
            new Order(1, "Alice", 250.50),
            new Order(2, "Bob", 150.75),
            new Order(3, "Charlie", 300.40),
            new Order(4, "David", 200.00),
            new Order(5, "Eve", 175.25)
        };
        quickSort(orders, 0, orders.length - 1);
        System.out.println("\nOrders sorted by Quick Sort:");
        printOrders(orders);
        orders = new Order[]{
            new Order(1, "Alice", 250.50),
            new Order(2, "Bob", 150.75),
            new Order(3, "Charlie", 300.40),
            new Order(4, "David", 200.00),
            new Order(5, "Eve", 175.25)
        };
        mergeSort(orders, 0, orders.length - 1);
        System.out.println("\nOrders sorted by Merge Sort:");
        printOrders(orders);
        orders = new Order[]{
            new Order(1, "Alice", 250.50),
            new Order(2, "Bob", 150.75),
            new Order(3, "Charlie", 300.40),
            new Order(4, "David", 200.00),
            new Order(5, "Eve", 175.25)
        };
        insertionSort(orders);
        System.out.println("\nOrders sorted by Insertion Sort:");
        printOrders(orders);
    }
    private static void printOrders(Order[] orders) {
        Arrays.stream(orders).forEach(System.out::println);
    }
}
