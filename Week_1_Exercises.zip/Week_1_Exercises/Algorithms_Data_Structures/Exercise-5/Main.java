import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
class Task {
    private int taskId;
    private String taskName;
    private String status;

    public Task(int taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }
    public int getTaskId() { return taskId; }
    public void setTaskId(int taskId) { this.taskId = taskId; }
    public String getTaskName() { return taskName; }
    public void setTaskName(String taskName) { this.taskName = taskName; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    @Override
    public String toString() {
        return "Task ID: " + taskId + ", Task Name: " + taskName + ", Status: " + status;
    }
}
class TaskManagementSystem {
    private final List<Task> tasks;
    public TaskManagementSystem() {
        tasks = new LinkedList<>();
    }
    public void addTask(Task task) {
        tasks.add(task);
    }
    public Task searchTaskById(int taskId) {
        return tasks.stream()
                .filter(task -> task.getTaskId() == taskId)
                .findFirst()
                .orElse(null);
    }
    public void traverseTasks() {
        tasks.forEach(System.out::println);
    }
    public void deleteTaskById(int taskId) {
        Optional<Task> taskOptional = tasks.stream()
                .filter(task -> task.getTaskId() == taskId)
                .findFirst();
        taskOptional.ifPresent(tasks::remove);
    }
}

public class Main {
    public static void main(String[] args) {
        TaskManagementSystem tms = new TaskManagementSystem();

        Task task1 = new Task(1, "Finish project report", "Pending");
        Task task2 = new Task(2, "Submit expense report", "Completed");
        Task task3 = new Task(3, "Prepare for team meeting", "Pending");

        tms.addTask(task1);
        tms.addTask(task2);
        tms.addTask(task3);

        System.out.println("All Tasks:");
        tms.traverseTasks();

        System.out.println("\nSearching for task with ID 2:");
        Task searchedTask = tms.searchTaskById(2);
        if (searchedTask != null) {
            System.out.println(searchedTask);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("\nDeleting task with ID 1.");
        tms.deleteTaskById(1);

        System.out.println("\nAll Tasks after deletion:");
        tms.traverseTasks();
    }
}
