public class Finance {
    public static double futureValue(double currentValue, double growthRate, int periods) {
        if (periods <= 0) {
            return currentValue;
        }
        return futureValue(currentValue * (1 + growthRate), growthRate, periods - 1);
    }
    public static double futureValueIterative(double currentValue, double growthRate, int periods) {
        double futureValue = currentValue;
        for (int i = 0; i < periods; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }
    public static void main(String[] args) {
        double currentValue = 1000;
        double growthRate = 0.05;
        int periods = 10;
        double futureValueRec = futureValue(currentValue, growthRate, periods);
        System.out.println("Recursive Future Value: $" + futureValueRec);
        double futureValueIt = futureValueIterative(currentValue, growthRate, periods);
        System.out.println("Iterative Future Value: $" + futureValueIt);
    }
}
