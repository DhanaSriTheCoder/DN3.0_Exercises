import java.util.HashMap;
public class InventoryManagementSystem {
    private final HashMap<Integer, Product> inventory;
    public InventoryManagementSystem() {
        inventory = new HashMap<>();
    }
    private void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }
    private void updateProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            inventory.put(product.getProductId(), product);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }
    public void deleteProduct(int productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
        } else {
            System.out.println("Product not found in inventory.");
        }
    }
    public void displayProducts() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();

        Product product1 = new Product(1, "Laptop", 10, 999.99);
        Product product2 = new Product(2, "Smartphone", 50, 499.99);
        ims.addProduct(product1);
        ims.addProduct(product2);
        ims.displayProducts();

        product1.setPrice(949.99);
        ims.updateProduct(product1);
        ims.displayProducts();

        ims.deleteProduct(2);
        ims.displayProducts();
    }
}
class Product {
    private int productId;
    private String productName;
    private int quantity;
    private double price;

    public Product(int productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }
    public int getProductId() {
        return productId;
    }
    public void setProductId(int productId) {
        this.productId = productId;
    }
    public String getProductName() {
        return productName;
    }
    public void setProductName(String productName) {
        this.productName = productName;
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    @Override
    public String toString() {
        return "Product [productId=" + productId + ", productName=" + productName + ", quantity=" + quantity + ", price=" + price + "]";
    }
}
