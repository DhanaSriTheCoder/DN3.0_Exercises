public class CommandPatternDemo {
    public interface Cmd {
        void execute();
    }
    public static class Light {
        public void on() {
            System.out.println("Light is ON");
        }
        public void off() {
            System.out.println("Light is OFF");
        }
    }
    public static class LightOffCmd implements Cmd {
        private final Light light;
        public LightOffCmd(Light light) {
            this.light = light;
        }
        @Override
        public void execute() {
            light.off();
        }
    }
    public static class LightOnCmd implements Cmd {
        private final Light light;
        public LightOnCmd(Light light) {
            this.light = light;
        }
        @Override
        public void execute() {
            light.on();
        }
    }
    public static class Remote {
        private Cmd cmd;
        public void setCmd(Cmd cmd) {
            this.cmd = cmd;
        }
        public void pressButton() {
            if (cmd != null) {
                cmd.execute();
            } else {
                System.out.println("No command set");
            }
        }
    }
    public static class TestCmd {
        public static void main(String[] args) {
            Light light = new Light();
            Cmd lightOn = new LightOnCmd(light);
            Cmd lightOff = new LightOffCmd(light);
            Remote remote = new Remote();
            remote.setCmd(lightOn);
            remote.pressButton();
            remote.setCmd(lightOff);
            remote.pressButton();
        }
    }
}
