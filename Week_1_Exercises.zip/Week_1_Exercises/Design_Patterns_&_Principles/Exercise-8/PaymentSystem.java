public class PaymentSystem {
    public interface PayStrategy {
        void pay(double amount);
    }
    public static class CreditCardPay implements PayStrategy {
        private final String cardNumber;
        public CreditCardPay(String cardNumber) {
            this.cardNumber = cardNumber;
        }
        @Override
        public void pay(double amount) {
            System.out.println("Paid $" + amount + " using Credit Card (" + cardNumber + ")");
        }
    }
    public static class PayPalPay implements PayStrategy {
        private final String email;
        public PayPalPay(String email) {
            this.email = email;
        }
        @Override
        public void pay(double amount) {
            System.out.println("Paid $" + amount + " using PayPal (" + email + ")");
        }
    }
    public static class PayContext {
        private PayStrategy strategy;
        public void setStrategy(PayStrategy strategy) {
            this.strategy = strategy;
        }
        public void executePayment(double amount) {
            if (strategy == null) {
                throw new IllegalStateException("Payment strategy not set");
            }
            strategy.pay(amount);
        }
    }
    public static class TestStrategy {
        public static void main(String[] args) {
            PayContext context = new PayContext();
            context.setStrategy(new CreditCardPay("1234-5678-9012-3456"));
            context.executePayment(100.00);
            context.setStrategy(new PayPalPay("john.doe@example.com"));
            context.executePayment(200.00);
        }
    }
}
