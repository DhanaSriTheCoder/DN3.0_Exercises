public class NotificationSystem {
    interface Notifier {
        void send(String msg);
    }
    static class Email implements Notifier {
        @Override
        public void send(String msg) {
            System.out.println("Email: " + msg);
        }
    }
    abstract static class Decorator implements Notifier {
        protected final Notifier notifier;
        protected Decorator(Notifier notifier) {
            this.notifier = notifier;
        }
        @Override
        public void send(String msg) {
            notifier.send(msg);
        }
    }
    static class SlackDecorator extends Decorator {
        public SlackDecorator(Notifier notifier) {
            super(notifier);
        }
        @Override
        public void send(String msg) {
            super.send(msg);
            System.out.println("Slack: " + msg);
        }
    }
    static class SMSDecorator extends Decorator {
        public SMSDecorator(Notifier notifier) {
            super(notifier);
        }
        @Override
        public void send(String msg) {
            super.send(msg);
            System.out.println("SMS: " + msg);
        }
    }
    public static void main(String[] args) {
        Notifier email = new Email();
        Notifier combined = new SMSDecorator(new SlackDecorator(email));
        combined.send("Hello World");
    }
}
