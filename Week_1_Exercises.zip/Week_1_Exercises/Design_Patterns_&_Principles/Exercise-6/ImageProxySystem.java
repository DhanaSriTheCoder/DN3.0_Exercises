public class ImageProxySystem {
    public interface Img {
        void display();
    }
    public static class ProxyImg implements Img {
        private final String fileName;
        private RealImg realImg;
        private boolean isLoaded = false;
        public ProxyImg(String fileName) {
            this.fileName = fileName;
        }
        @Override
        public void display() {
            if (!isLoaded) {
                realImg = new RealImg(fileName);
                isLoaded = true;
            }
            realImg.display();
        }
    }
    public static class RealImg implements Img {
        private final String fileName;
        public RealImg(String fileName) {
            this.fileName = fileName;
            loadImageFromServer();
        }
        private void loadImageFromServer() {
            System.out.println("Loading image: " + fileName);
        }
        @Override
        public void display() {
            System.out.println("Displaying image: " + fileName);
        }
    }
    public static class TestProxy {
        public static void main(String[] args) {
            Img img1 = new ProxyImg("image1.jpg");
            Img img2 = new ProxyImg("image2.jpg");
            img1.display(); 
            img1.display();
            img2.display();
            img2.display();
        }
    }
}
