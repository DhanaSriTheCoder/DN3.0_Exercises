public class StudentManagementSystem {
    public static void main(String[] args) {
        Student model = new Student("1", "John Doe", "A");
        StuView view = new StuView();
        StuCtrl controller = new StuCtrl(model, view);
        controller.updateView();
        controller.setStuName("Jane Smith");
        controller.setStuGrade("B");
        controller.updateView();
    }
    public static class StuCtrl {
        private final Student model;
        private final StuView view;
        public StuCtrl(Student model, StuView view) {
            this.model = model;
            this.view = view;
        }
        public void setStuName(String name) {
            model.setName(name);
        }
        public String getStuName() {
            return model.getName();
        }
        public void setStuId(String id) {
            model.setId(id);
        }
        public String getStuId() {
            return model.getId();
        }
        public void setStuGrade(String grade) {
            model.setGrade(grade);
        }
        public String getStuGrade() {
            return model.getGrade();
        }
        public void updateView() {
            view.displayStuDetails(model.getId(), model.getName(), model.getGrade());
        }
    }
    public static class Student {
        private String id;
        private String name;
        private String grade;
        public Student(String id, String name, String grade) {
            this.id = id;
            this.name = name;
            this.grade = grade;
        }
        public String getId() {
            return id;
        }
        public void setId(String id) {
            this.id = id;
        }
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public String getGrade() {
            return grade;
        }
        public void setGrade(String grade) {
            this.grade = grade;
        }
    }
    public static class StuView {
        public void displayStuDetails(String id, String name, String grade) {
            System.out.println("Student: ");
            System.out.println("ID: " + id);
            System.out.println("Name: " + name);
            System.out.println("Grade: " + grade);
        }
    }
}
