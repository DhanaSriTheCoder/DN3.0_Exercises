public class TestComputerBuilder {
    public static void main(String[] args) {
        Computer basicComputer = new Computer.Builder("Intel i5", "8GB RAM").build();
        System.out.println("Basic Computer: " + basicComputer);
        Computer gamingComputer = new Computer.Builder("AMD Ryzen 7", "16GB RAM")
                .withStorage("1TB SSD")
                .withGraphicsCard(true)
                .withBluetooth(true)
                .build();
        System.out.println("Gaming Computer: " + gamingComputer);
        Computer officeComputer = new Computer.Builder("Intel i7", "32GB RAM")
                .withStorage("512GB SSD")
                .withGraphicsCard(false)
                .withBluetooth(false)
                .build();
        System.out.println("Office Computer: " + officeComputer);
    }
}
class Computer {
    private final String CPU;
    private final String RAM;
    private final String storage;
    private final boolean isGraphicsCardIncluded;
    private final boolean isBluetoothEnabled;
    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.isGraphicsCardIncluded = builder.isGraphicsCardIncluded;
        this.isBluetoothEnabled = builder.isBluetoothEnabled;
    }
    public static class Builder {
        private final String CPU;
        private final String RAM;
        private String storage = "256GB SSD";
        private boolean isGraphicsCardIncluded = false;
        private boolean isBluetoothEnabled = false;
        public Builder(String CPU, String RAM) {
            this.CPU = CPU;
            this.RAM = RAM;
        }
        public Builder withStorage(String storage) {
            this.storage = storage;
            return this;
        }
        public Builder withGraphicsCard(boolean isGraphicsCardIncluded) {
            this.isGraphicsCardIncluded = isGraphicsCardIncluded;
            return this;
        }
        public Builder withBluetooth(boolean isBluetoothEnabled) {
            this.isBluetoothEnabled = isBluetoothEnabled;
            return this;
        }
        public Computer build() {
            return new Computer(this);
        }
    }
    @Override
    public String toString() {
        return String.format("Computer{CPU='%s', RAM='%s', storage='%s', graphicsCard=%s, bluetooth=%s}",
                CPU, RAM, storage, isGraphicsCardIncluded, isBluetoothEnabled);
    }
}
