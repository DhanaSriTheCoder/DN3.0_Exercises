import java.util.ArrayList;
import java.util.List;
public class StockObserverSystem {
    public interface Observer {
        void update();
    }
    public interface Stock {
        void registerObserver(Observer observer);
        void deregisterObserver(Observer observer);
        void notifyObservers();
    }
    public static class Market implements Stock {
        private final List<Observer> observers = new ArrayList<>();
        private double price;
        public void setPrice(double price) {
            this.price = price;
            notifyObservers();
        }
        public double getPrice() {
            return price;
        }
        @Override
        public void registerObserver(Observer observer) {
            observers.add(observer);
        }
        @Override
        public void deregisterObserver(Observer observer) {
            observers.remove(observer);
        }
        @Override
        public void notifyObservers() {
            for (Observer observer : observers) {
                observer.update();
            }
        }
    }
    public static class Mobile implements Observer {
        private final Market market;
        public Mobile(Market market) {
            this.market = market;
        }
        @Override
        public void update() {
            System.out.println("Mobile App: Stock price updated to $" + market.getPrice());
        }
    }
    public static class Web implements Observer {
        private final Market market;
        public Web(Market market) {
            this.market = market;
        }
        @Override
        public void update() {
            System.out.println("Web App: Stock price updated to $" + market.getPrice());
        }
    }
    public static class TestObserver {
        public static void main(String[] args) {
            Market market = new Market();
            Observer mobileApp = new Mobile(market);
            Observer webApp = new Web(market);
            market.registerObserver(mobileApp);
            market.registerObserver(webApp);
            market.setPrice(150.00);
            market.setPrice(155.50);
        }
    }
}
