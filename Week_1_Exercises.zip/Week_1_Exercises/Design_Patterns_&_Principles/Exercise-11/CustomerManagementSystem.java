public class CustomerManagementSystem {
    public static void main(String[] args) {
        CustRepo repo = new CustRepoImpl();
        CustService service = new CustService(repo);
        Customer customer = service.getCustById("1");
        System.out.println("Customer ID: " + customer.getId());
        System.out.println("Customer Name: " + customer.getName());
    }
    public static class Customer {
        private final String id;
        private final String name;
        public Customer(String id, String name) {
            this.id = id;
            this.name = name;
        }
        public String getId() {
            return id;
        }
        public String getName() {
            return name;
        }
    }
    public interface CustRepo {
        Customer findCustById(String id);
    }
    public static class CustRepoImpl implements CustRepo {
        @Override
        public Customer findCustById(String id) {
            return new Customer(id, "John Doe");
        }
    }
    public static class CustService {
        private final CustRepo repo;
        public CustService(CustRepo repo) {
            this.repo = repo;
        }
        public Customer getCustById(String id) {
            return repo.findCustById(id);
        }
    }
}
