public class TestFactoryMethod {
    public static void main(String[] args) {
        testDocumentFactory("Word");
        testDocumentFactory("PDF");
        testDocumentFactory("Excel");
    }
    private static void testDocumentFactory(String type) {
        DocumentFactory factory = DocumentFactory.getFactory(type);
        Document doc = factory.createDocument();
        doc.open();
        doc.save();
        doc.close();
    }
}
interface Document {
    void open();
    void save();
    void close();
}
class ConcreteDocument implements Document {
    private final String type;
    public ConcreteDocument(String type) {
        this.type = type;
    }
    @Override
    public void open() {
        System.out.println("Opening " + type + " document...");
    }
    @Override
    public void save() {
        System.out.println("Saving " + type + " document...");
    }
    @Override
    public void close() {
        System.out.println("Closing " + type + " document...");
    }
}
abstract class DocumentFactory {
    public abstract Document createDocument();
    public static DocumentFactory getFactory(String type) {
        return new ConcreteDocumentFactory(type);
    }
}
class ConcreteDocumentFactory extends DocumentFactory {
    private final String documentType;
    public ConcreteDocumentFactory(String documentType) {
        this.documentType = documentType;
    }
    @Override
    public Document createDocument() {
        return new ConcreteDocument(documentType);
    }
}
