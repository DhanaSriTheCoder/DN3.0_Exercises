interface PaymentProcessor {
    void processPayment(double amount);
}
class PayPalAdapter implements PaymentProcessor {
    private final PayPalGateway payPalGateway;
    public PayPalAdapter(PayPalGateway payPalGateway) {
        this.payPalGateway = payPalGateway;
    }
    @Override
    public void processPayment(double amount) {
        payPalGateway.makePayment(amount);
    }
}
class PayPalGateway {
    public void makePayment(double amount) {
        System.out.println("Processing payment through PayPal: $" + amount);
    }
}
class StripeAdapter implements PaymentProcessor {
    private final StripeGateway stripeGateway;
    public StripeAdapter(StripeGateway stripeGateway) {
        this.stripeGateway = stripeGateway;
    }
    @Override
    public void processPayment(double amount) {
        stripeGateway.charge(amount);
    }
}
class StripeGateway {
    public void charge(double amount) {
        System.out.println("Processing payment through Stripe: $" + amount);
    }
}
public class TestAdapterPattern {
    public static void main(String[] args) {
        PayPalGateway payPalGateway = new PayPalGateway();
        StripeGateway stripeGateway = new StripeGateway();
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripeGateway);
        testPaymentProcessor(payPalAdapter, 100.00);
        testPaymentProcessor(stripeAdapter, 200.00);
    }
    private static void testPaymentProcessor(PaymentProcessor processor, double amount) {
        processor.processPayment(amount);
    }
}
