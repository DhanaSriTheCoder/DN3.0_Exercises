package com.library.repository;
import org.springframework.stereotype.Repository;
@Repository
public class BookRepository {
    // Simulate database operations
    public void save(String book) {
        System.out.println("Book saved: " + book);
    }
    public String find(String bookId) {
        return "Book with ID: " + bookId;
    }
}
