package com.library.repository;
import org.springframework.stereotype.Repository;
@Repository
public class BookRepository {
    public void saveBook(String bookTitle) {
        System.out.println("Saving book: " + bookTitle);
    }
    public String findBook(String bookTitle) {
        System.out.println("Finding book: " + bookTitle);
        return "Sample Book";
    }
    public void deleteBook(String bookTitle) {
        System.out.println("Deleting book: " + bookTitle);
    }
}
