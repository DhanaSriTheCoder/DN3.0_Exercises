package com.library.repository;
import org.springframework.stereotype.Repository;
import java.util.HashMap;
import java.util.Map;
@Repository
public class BookRepository {
    private final Map<Integer, String> bookStore = new HashMap<>();
    public void save(int id, String title) {
        bookStore.put(id, title);
    }
    public String findById(int id) {
        return bookStore.get(id);
    }
}
