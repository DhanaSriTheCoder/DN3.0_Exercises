package com.library.repository;
public class BookRepository {
    // Example method
    public void findBooks() {
        System.out.println("Finding books...");
    }
}
