package com.example.BookstoreAPI.controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.BookstoreAPI.dto.CustomerDTO;
import com.example.BookstoreAPI.entity.Customer;
import java.util.ArrayList;
import java.util.List;
@RestController
@RequestMapping("/customers")
public class CustomerController {
    private List<Customer> customers = new ArrayList<>();
    @GetMapping
    public List<Customer> getAllCustomers() {
        return customers;
    }
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Customer createCustomer(@RequestBody Customer customer) {
        customers.add(customer);
        return customer;
    }
    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Customer> registerCustomer(@RequestParam String name, @RequestParam String email, @RequestParam String password) {
        Customer customer = new Customer(customers.size() + 1, name, email, password);
        customers.add(customer);
        return new ResponseEntity<>(customer, HttpStatus.CREATED);
    }
}
