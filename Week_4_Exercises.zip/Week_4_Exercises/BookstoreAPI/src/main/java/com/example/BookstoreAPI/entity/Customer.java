package com.example.BookstoreAPI.entity;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class Customer {
    private int id;
    private String name;
    private String email;
    private String password;
    public Customer(int id, String name, String email, String password){
        this.id = id;
        this.email = email;
        this.name = name;
        this.password = password;
    }
}